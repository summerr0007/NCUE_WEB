<?php


$config['db']['host'] = 'localhost';
$config['db']['username'] = 'root';
$config['db']['password'] = 'root123456';
$config['db']['dbname'] = 'group_14';


$config['defaultController'] = 'Item';
$config['defaultAction'] = 'index';

return $config;