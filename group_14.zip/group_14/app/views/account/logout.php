<script>
    alert("<?php echo $logout; ?>");
    location.href = '<?php echo THISURL;?>';
</script>
