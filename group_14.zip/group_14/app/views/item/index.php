<div class="container-xxl">
    <div class="row">
        <aside class="col-3 border border-primary">
            <nav>
                <ui>
                    <?php foreach($items as $item):?>
                        <li><a href="<?php echo THISURL."item/detail/".$item['id'];?>"><?php echo $item['name'];?></a></li>
                    <?php endforeach ?>
                </ui>
            </nav>
        </aside>
        <main class="col-9" >
            <div class="row align-items-start">
                <?php foreach($items as $item):?>
                    <div class="col-3 border border-success gx-5">
                        <img class= "rounded mx-auto d-block" src='<?php echo $thisurl.'static/'.$item['src'];?>'>
                        <p class ="text-center" ><?php echo $item['name'];?><br></p>
                        <p class ="text-center" >$22.44<p>
                        <p class ="text-center" ><a href="<?php echo $thisurl;?>item/detail/<?php echo $item['id'] ?>".>detail</a></p>
                    </div>
                <?php endforeach ?>
            </div>
        </main>
    </div>
</div>