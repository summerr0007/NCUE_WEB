<div class="container-xxl">
    <div class="row">
        <main class="col" >
            <img class= "rounded mx-auto d-block" src='<?php echo $thisurl.'static/'.$item['src'];?>'>
            <p class ="text-center" ><?php echo $item['name'];?><br></p>
            <p class ="text-center" >$22.44<p>
            <p class ="text-center" ><a href="javascript:alert('施工中')">加入購物車</a></p>
        </main>
    </div>
</div>